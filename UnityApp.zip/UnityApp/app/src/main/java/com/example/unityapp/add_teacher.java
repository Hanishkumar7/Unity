package com.example.unityapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class add_teacher extends AppCompatActivity {

    EditText edtxtaddteach,edtxtaddteach1;
    Button btnaddteach;

    DatabaseReference databaseaddteach;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_teacher);

        databaseaddteach=FirebaseDatabase.getInstance().getReference("addteache");

        edtxtaddteach=(EditText)findViewById(R.id.editTextaddteach);
        edtxtaddteach1=(EditText)findViewById(R.id.editTextaddteach1);
        btnaddteach=(Button)findViewById(R.id.buttonaddeteach);

        btnaddteach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             addteach();
            }
        });

    }
    private void addteach(){
        String tid=edtxtaddteach.getText().toString().trim();
        String tpass=edtxtaddteach1.getText().toString().trim();

        if(!TextUtils.isEmpty(tid)){
            String idte=databaseaddteach.push().getKey();

            addingteach addingteach=new addingteach(idte,tid,tpass);

            databaseaddteach.child(idte).setValue(addingteach);
    }else {
            Toast.makeText(this,"Enter the Teacher ID",Toast.LENGTH_LONG).show();
        }

    }

}
