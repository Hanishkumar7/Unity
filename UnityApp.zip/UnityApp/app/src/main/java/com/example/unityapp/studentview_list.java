package com.example.unityapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class studentview_list extends AppCompatActivity {
    ListView stulist;
    DatabaseReference databaseaddstud;
    List<addingstu> studentelst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studentview_list);

        databaseaddstud = FirebaseDatabase.getInstance().getReference("addstudent");

        stulist=(ListView)findViewById(R.id.listViewstudentsview);

        studentelst=new ArrayList<>();
    }

    @Override
    protected void onStart() {
        super.onStart();
        databaseaddstud.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                studentelst.clear();
                for(DataSnapshot studeSnapshot: dataSnapshot.getChildren()){
                    addingstu addingstu=studeSnapshot.getValue(addingstu.class);

                    studentelst.add(addingstu);
                }

                viewstude_list adapter=new viewstude_list(studentview_list.this,studentelst);
                stulist.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
