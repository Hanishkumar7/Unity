package com.example.unityapp;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button btn;

   /*Button login;
    EditText id,password;
    Spinner spinnerloginas;
    String userrole;
    private String[] userRoleString = new String[] { "Admin", "Teacher"}; */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn=(Button)findViewById(R.id.buttonlogin);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,admin_home.class);
                startActivity(intent);

            }
        });



        /*login =(Button)findViewById(R.id.buttonlogin);
        id=(EditText)findViewById(R.id.editTextusername);
        password=(EditText)findViewById(R.id.editTextpassword);
        spinnerloginas=(Spinner)findViewById(R.id.spinnerloginas);

        spinnerloginas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view,
                                       int arg2, long arg3) {

                ((TextView) arg0.getChildAt(0)).setTextColor(Color.BLACK);
                userrole =(String) spinnerloginas.getSelectedItem();

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });

        ArrayAdapter<String> adapter_role = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, userRoleString);
        adapter_role
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerloginas.setAdapter(adapter_role);

        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                if(userrole.equals("Admin"))
                {

                    String i_d = id.getText().toString();
                    String pass_word = password.getText().toString();

                    if (TextUtils.isEmpty(i_d))
                    {
                        id.setError("Invalid ID");
                    }
                    else if(TextUtils.isEmpty(pass_word))
                    {
                        password.setError("Enter Password");
                    }
                    else
                    {
                        if(i_d.equals("admin") & pass_word.equals("admin123")){
                            Intent intent =new Intent(MainActivity.this,admin_home.class);
                            startActivity(intent);
                            Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                else
                {
                    String i_d = id.getText().toString();
                    String pass_word = password.getText().toString();

                    if (TextUtils.isEmpty(i_d))
                    {
                        id.setError("Invalid ID");
                    }
                    else if(TextUtils.isEmpty(pass_word))
                    {
                        password.setError("Enter Password");
                    }

                    FacultyBean facultyBean = database.validateFaculty(i_d, pass_word);

                    if(facultyBean!=null)
                    {
                        Intent intent = new Intent(MainActivity.this,AddAttandanceSessionActivity.class);
                        startActivity(intent);
                        ((ApplicationContext)MainActivity.this.getApplicationContext()).setFacultyBean(facultyBean);
                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });



    */
    }


}
