package com.example.unityapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class student_admin extends AppCompatActivity {

    Button addbtn,remobtn,viewbtn,logoutstubtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_admin);

        addbtn=(Button)findViewById(R.id.butonstuadde);
        remobtn=(Button)findViewById(R.id.buttonsturemo);
        viewbtn=(Button)findViewById(R.id.buttonstuview);
        logoutstubtn=(Button)findViewById(R.id.buttonlogostu);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(student_admin.this,add_student.class);
                startActivity(intent);
            }
        });

        remobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(student_admin.this,remove_student.class);
                startActivity(intent);
            }
        });

        viewbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(student_admin.this,view_student.class);
                startActivity(intent);
            }
        });

        logoutstubtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(student_admin.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
