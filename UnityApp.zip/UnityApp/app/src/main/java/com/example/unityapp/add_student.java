package com.example.unityapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class add_student extends AppCompatActivity {

    EditText edtxtaddstu, edtxtaddstu1,edtxtaddstu2,edtxtaddstu3;
    Button btnaddstu;
    Spinner spinaddstu,spinaddstu1;

    DatabaseReference databaseaddstud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_student);

        databaseaddstud= FirebaseDatabase.getInstance().getReference("addstudent");

        edtxtaddstu = (EditText) findViewById(R.id.editTextaddstu);
        edtxtaddstu1 = (EditText) findViewById(R.id.editTextaddstu1);
        edtxtaddstu2=(EditText)findViewById(R.id.editTextaddstu3);
        edtxtaddstu3=(EditText)findViewById(R.id.editTextaddstu2);
        btnaddstu = (Button) findViewById(R.id.buttonaddstu);
        spinaddstu=(Spinner)findViewById(R.id.spinneraddstu);
        spinaddstu1=(Spinner)findViewById(R.id.spinneraddstu1);

        btnaddstu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            addstud();

                Intent intent=new Intent(add_student.this,student_admin.class);
                startActivity(intent);

           Toast.makeText(v.getContext(),"Student Added",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void addstud() {
        String id = edtxtaddstu.getText().toString().trim();
        String stuname = edtxtaddstu1.getText().toString().trim();
        String stupho=edtxtaddstu2.getText().toString().trim();
        String stuaddres=edtxtaddstu3.getText().toString().trim();
        String stucourse=spinaddstu1.getSelectedItem().toString().trim();
        String stuintake=spinaddstu.getSelectedItem().toString().trim();

        if (!TextUtils.isEmpty(id)) {

            String ids=databaseaddstud.push().getKey();

           addingstu addingstu = new addingstu(ids,id,stuname,stupho,stuaddres,stucourse,stuintake);
           databaseaddstud.child(ids).setValue(addingstu);

        }
        else {
            Toast.makeText(this,"Enter the Details",Toast.LENGTH_LONG).show();
        }

    }
}
