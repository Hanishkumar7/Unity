package com.example.unityapp;

public class addingteach {

    String  adduniqeidteach;
    String  teacherid;
    String teacherpass;

    public addingteach(){

    }

    public addingteach(String adduniqeidteach, String teacherid, String teacherpass) {
        this.adduniqeidteach = adduniqeidteach;
        this.teacherid = teacherid;
        this.teacherpass = teacherpass;
    }

    public String getAdduniqeidteach() {
        return adduniqeidteach;
    }

    public String getTeacherid() {
        return teacherid;
    }

    public String getTeacherpass() {
        return teacherpass;
    }
}
