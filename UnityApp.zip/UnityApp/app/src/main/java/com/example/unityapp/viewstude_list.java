package com.example.unityapp;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class viewstude_list extends ArrayAdapter<addingstu> {

    private Activity context;
    private List<addingstu>viewst;

    public viewstude_list(Activity context, List<addingstu> viewst){
        super(context, R.layout.viewstu_listview,viewst);
        this.context=context;
        this.viewst=viewst;

    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();

        View listitem=inflater.inflate(R.layout.viewstu_listview,null,true);

        TextView textViewstudeid=(TextView)listitem.findViewById(R.id.textViewstudeid);
        TextView textViewstudename=(TextView)listitem.findViewById(R.id.textViewstudename);
        TextView textViewstudephn=(TextView)listitem.findViewById(R.id.textViewstudephn);
        TextView textViewstudeaddre=(TextView)listitem.findViewById(R.id.textViewstudeaddre);
        TextView textViewstudecour=(TextView)listitem.findViewById(R.id.textViewstudecour);
        TextView textViewstudeinta=(TextView)listitem.findViewById(R.id.textViewstudeinta);

        addingstu addingstu=viewst.get(position);

        textViewstudeid.setText(addingstu.studid);
        textViewstudename.setText(addingstu.studnam);
        textViewstudephn.setText(addingstu.studphn);
        textViewstudeaddre.setText(addingstu.studaddre);
        textViewstudecour.setText(addingstu.stucourse);
        textViewstudeinta.setText(addingstu.stucourse);

        return listitem;

    }
}
