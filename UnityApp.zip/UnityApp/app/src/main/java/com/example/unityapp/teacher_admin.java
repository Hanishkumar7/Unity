package com.example.unityapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class teacher_admin extends AppCompatActivity {

    Button btnadde,btnremo,btnview,btnlogoutteach;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_admin);

        btnadde=(Button)findViewById(R.id.buttonaddeteach);
        btnremo=(Button)findViewById(R.id.buttonremoteach);
        btnview=(Button)findViewById(R.id.buttonviewteach);
        btnlogoutteach=(Button)findViewById(R.id.buttonlogoteach);

        btnadde.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(teacher_admin.this,add_teacher.class);
                startActivity(intent);
            }
        });

        btnremo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(teacher_admin.this,remove_teacher.class);
                startActivity(intent);
            }
        });

        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(teacher_admin.this,view_teacher.class);
                startActivity(intent);
            }
        });

        btnlogoutteach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(teacher_admin.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
