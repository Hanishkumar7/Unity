package com.example.unityapp;

public class addingstu {

    String stuniqeid;
    String studid;
    String studnam;
    String studphn;
    String studaddre;
    String stuintake;
    String stucourse;

    public  addingstu(String id, String stuname, String stupho, String stuaddres, String stucourse, String stuintake){

    }

    public addingstu(String stuniqeid, String studid, String studnam, String studphn, String studaddre, String stuintake, String stucourse) {
        this.stuniqeid = stuniqeid;
        this.studid = studid;
        this.studnam = studnam;
        this.studphn = studphn;
        this.studaddre = studaddre;
        this.stuintake = stuintake;
        this.stucourse = stucourse;
    }

    public String getStuniqeid() {
        return stuniqeid;
    }

    public String getStudid() {
        return studid;
    }

    public String getStudnam() {
        return studnam;
    }

    public String getStudphn() {
        return studphn;
    }

    public String getStudaddre() {
        return studaddre;
    }

    public String getStuintake() {
        return stuintake;
    }

    public String getStucourse() {
        return stucourse;
    }
}
